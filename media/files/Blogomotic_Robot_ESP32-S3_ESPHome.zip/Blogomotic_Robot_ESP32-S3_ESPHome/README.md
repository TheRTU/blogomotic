# Robot de bureau ESP32-S3 : sources ESPHome (Blogomotic)

Configuration anonymisée du robot de bureau à **deux écrans ronds GC9A01A**, anneau de 12 LED RGB et buzzer. Les fichiers sont fournis **à titre d'exemple** pour être adaptés à votre installation Home Assistant.

## Important : à lire avant de flasher

Les **5 packages YAML** et le fichier **`robot_state.h`** viennent du projet transmis, anonymisé. En revanche, **le fichier YAML principal d'origine n'a pas été fourni** : `robot-table-s3.yaml` est donc **un modèle reconstitué**, non une copie validée de la configuration en service. Il faudra éventuellement l'ajuster (carte exacte, version ESPHome, paramètres réseau, flash, etc.).

**La police `DejaVuSansMono.ttf` n'est pas incluse.** Ajoutez-la vous-même comme indiqué ci-dessous. Sans elle, le projet ne pourra pas être compilé.

Les fichiers YAML ont été analysés syntaxiquement et la cohérence des chemins a été contrôlée. **Aucune compilation ni validation sur l'ESP32 physique n'a été effectuée.**

## Arborescence

```text
robot-table-s3.yaml                 <- fichier principal d'exemple
secrets.example.yaml               <- uniquement un aide-mémoire, pas un secret réel
robot-table-s3/
  robot_state.h                     <- moteur de scènes, veille, messages
  DejaVuSansMono.ttf                <- À AJOUTER, absent de l'archive
  packages/
    display.yaml                    <- 2 écrans, heure, températures
    buzzer.yaml                     <- buzzer et airs RTTTL
    eyes.yaml                       <- cycle et animations
    led.yaml                        <- anneau et LED de carte
    presence.yaml                   <- présence, veille, mise à jour HA, messages
  fonts/
    COPYRIGHT-DejaVu.txt           <- notice de licence de la police
```

## Mise en place

1. Décompresser **le contenu** de l'archive dans le répertoire de configuration ESPHome (habituellement `/config/esphome/` dans Home Assistant), en conservant les chemins ci-dessus. Vous devez notamment obtenir `/config/esphome/robot-table-s3.yaml` et `/config/esphome/robot-table-s3/robot_state.h`.
2. Récupérer `DejaVuSansMono.ttf` depuis votre distribution Linux ou le [projet DejaVu](https://dejavu-fonts.github.io/), puis placer **ce fichier avec ce nom** dans `robot-table-s3/`. Sous Ubuntu, il est généralement disponible dans `/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf`. Les conditions de redistribution sont documentées dans `robot-table-s3/fonts/COPYRIGHT-DejaVu.txt`.
3. Dans votre **`secrets.yaml` ESPHome personnel**, déclarer `wifi_ssid`, `wifi_password`, `robot_api_encryption_key`, `robot_ota_password` avec vos propres valeurs. Voir `secrets.example.yaml` comme aide-mémoire. Ne publiez jamais les secrets réels. Générez une clé d'API ESPHome valide (chaîne Base64 appropriée) et un mot de passe OTA.
4. Modifier si nécessaire le modèle de carte / framework dans `robot-table-s3.yaml`, puis adapter les entités Home Assistant listées ci-dessous.
5. Vérifier la configuration depuis ESPHome et **compiler** avant de flasher. Contrôler ensuite le fonctionnement matériel et les réactions aux événements.

## Entités Home Assistant à adapter

| Fichier | Entité générique | Rôle |
|---|---|---|
| `display.yaml` | `sensor.temperature_exterieure_nord` | Température pour l'écran gauche |
| `display.yaml` | `sensor.temperature_exterieure_sud` | Température pour l'écran droit |
| `presence.yaml` | `binary_sensor.presence_bureau` | Capteur de mouvement/présence (états `on`/`off`) |
| `presence.yaml` | `input_boolean.robot_alerte_maj` | Indicateur de mise à jour Home Assistant en attente |

Vous devrez créer/configurer ces entités (ou changer les identifiants). Un **texte libre** apparaît comme entité de type `text` via ESPHome et peut être commandé depuis Home Assistant.

L'heure utilise Home Assistant avec le fuseau `Europe/Paris` : le modifier dans `display.yaml` si nécessaire.

## Matériel et branchements (ne pas modifier les GPIO sans adapter le câblage)

- ESP32-S3 DevKitC-1 N16R8 (16 Mo flash, 8 Mo PSRAM, selon le modèle utilisé).
- Deux écrans GC9A01A SPI 1,28 pouce : MOSI **GPIO11** et CLK **GPIO12** communs ; DC **GPIO10** commun ; RESET **GPIO9** commun ; CS gauche **GPIO13**, CS droit **GPIO14**.
- Anneau de 12 LED WS2812B : données **GPIO15**.
- LED RGB intégrée de carte : **GPIO48**.
- Buzzer passif HW-508 : signal **GPIO16**.
- **Toutes les masses (GND) doivent être communes.** Les écrans et LED nécessitent une alimentation adaptée. Vérifier les tensions du matériel réel avant tout branchement.

## Comportement

- Cycle normal : **20 s yeux**, **5 s heure**, **5 s températures**.
- Mise en veille après **15 min d'absence** ; réveil au retour de la présence.
- Priorités : **mise à jour HA > message temporaire > veille > cycle normal**.
- Message personnalisé : jusqu'à 56 caractères, affiché environ **15 s** sur les deux écrans.
- Alerte HA : `MAJ` / `HA` en rouge sur les écrans, clignotement rouge des LED.
- Buzzer : petit son au réveil, double bip entre 9 h et 20 h, et quelques airs RTTTL pilotables depuis Home Assistant.

## Notes et limites

- L'enregistrement des capteurs Home Assistant et la présence des entités sont nécessaires aux informations affichées. Les textes `unknown` / `unavailable` ne doivent pas être pris pour une absence confirmée.
- Le fichier `buzzer.yaml` contient des transcriptions RTTTL de thèmes d'œuvres connues, transmises avec le projet. Vérifier les droits applicables avant toute republication publique ou distribution élargie.
- Le code et la configuration sont partagés sans garantie de fonctionnement sur d'autres installations. Ne flashez pas sans une vérification préalable du matériel et des GPIO.

Blogomotic : https://thertu.github.io/blogomotic/
