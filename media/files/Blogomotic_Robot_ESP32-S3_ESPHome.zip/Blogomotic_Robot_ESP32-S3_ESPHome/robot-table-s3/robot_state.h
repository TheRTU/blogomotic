#pragma once
#include <cstdint>
#include <string>

// Logique indépendante du dessin et du matériel.
struct RobotState {
  enum Scene { NORMAL = 0, SLEEP = 1, UPDATE = 2, MESSAGE = 3 };
  bool sleeping = false;
  bool maj = false;
  bool absence_tracking = false;
  uint32_t absence_since = 0;
  uint32_t generation = 0;
  uint32_t message_since = 0;
  std::string message;

  Scene scene(uint32_t now) const {
    if (maj) return UPDATE;
    if (!message.empty() && uint32_t(now - message_since) < 15000U) return MESSAGE;
    return sleeping ? SLEEP : NORMAL;
  }

  // presence : 1 = on, 0 = off, -1 = inconnu/indisponible.
  // Retourne vrai uniquement lors d'un réveil visuel par présence.
  bool tick(uint32_t now, int presence) {
    if (presence == 1) {
      absence_tracking = false;
      if (sleeping) {
        const bool sound = scene(now) == SLEEP;
        sleeping = false;
        ++generation;
        return sound;
      }
    } else if (presence == 0) {
      if (!absence_tracking) {
        absence_since = now;
        absence_tracking = true;
      }
      if (uint32_t(now - absence_since) >= 900000U) sleeping = true;
    } else {
      // Un défaut de capteur n'est pas une absence confirmée.
      absence_tracking = false;
    }
    return false;
  }

  void set_maj(bool active) {
    if (maj == active) return;
    maj = active;
    if (!active) {
      sleeping = false;
      absence_tracking = false;
      message.clear();
      ++generation;
    }
  }

  void set_message(const std::string &value, uint32_t now) {
    message = value;
    message_since = now;
  }
};

// Instance partagée par les lambdas ESPHome après inclusion du fichier.
inline RobotState robot_control;
